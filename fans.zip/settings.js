var settings = {
    host : 'localhost',
    port : '4444',
    ip: '192.168.1.3'
};